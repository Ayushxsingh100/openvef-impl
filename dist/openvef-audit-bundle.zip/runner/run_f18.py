"""F18 fixture runner (v1.3.6).

Implements the runner duties in Catalog (file 36) "Fixture requirements" 1-6 and L176:
verify the index, every descriptor's SHA-256 and byte length, the exact count (144),
then execute each fixture and compare exact expected values.

Rules (CLAUDE.md): the code path is chosen from the fixture INPUT shape only, never
from its ID or expected output. A fixture whose path reaches a stage that is not yet
implemented is reported NOT_IMPLEMENTED -- never PASS.

Usage (evidence, D-002a):  runner/run_f18_container.sh <run_class>
Usage (development only):  python3.11 -I runner/run_f18.py <baseline_root> <evidence_dir> <run_class>
"""
from __future__ import annotations

import base64
import datetime as dt
import hashlib
import importlib.metadata
import json
import os
import platform
import subprocess
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "src"))

from openvef.envelope import Envelope, Failure, parse_envelope  # noqa: E402
from openvef.schema import SCHEMA_REL, ValidatedResponse, load_validator, validate_clause_ids, validate_schema  # noqa: E402
from openvef.import_policy import check_import_policy  # noqa: E402
from openvef.ast_signature import check_ast_signature, check_compile  # noqa: E402
from openvef.assembler import NEAR_MATCH_REGEX_DEFAULT, SEARCH_REGEX_DEFAULT, check_visible_clause_ids  # noqa: E402
from openvef.runtime import RuntimeStageError, factory_checks  # noqa: E402
from openvef.sandbox import SandboxUnavailable, broker_mode, ensure_image  # noqa: E402
from openvef import simulator_stages  # noqa: E402
from openvef.simulation import SimulationError  # noqa: E402
from openvef.ledger import HaltSignature, SignatureDomainError, halt_after_recovery, lifecycle_expectation  # noqa: E402
from openvef.stage_map import (EventError, NotDetermined, adjudicate_checker, first_event,  # noqa: E402
                               outcome_from_record)
from openvef.source_ast import UnsettledSpec, check_sources  # noqa: E402

INDEX_REL = "41_F18_Fixture_Inputs/fixture-index.json"
INDEX_SHA256 = "f37808c7a662b8fdf164e27feaef023aadd6dfefaada35d11c3719185d1bde54"
EXPECTED_COUNT = 144
COMPARE_KEYS = ("disposition", "stage_id", "error_class", "diagnostic")
# 27_SHA256SUMS.txt entry for the canonical response schema (File 30 §1).
SCHEMA_SHA256 = "6fb5d282b09540949f21ee134b522841c3345031cb3e118a83bdffc18b4e7c34"
PINNED_DISTRIBUTIONS = ("jsonschema", "attrs", "jsonschema-specifications", "referencing", "rpds-py",
                        "typing_extensions", "cocotb", "find-libpython", "iniconfig", "packaging", "pluggy",
                        "pygments", "pytest")
# D-002a: the pinned interpreter for all F18 evidence is CPython 3.11.18 in the
# python:3.11.18-slim image pinned by digest (docs/sandbox.md).
PINNED_PYTHON_VERSION = "3.11.18 (main, Nov  5 2026, 07:57:53) [GCC 14.2.0]"
PINNED_PYTHON_SHA256 = "92d7e40ec50be176cb1b790c7568b7e08cd862137b5aa69f1413ba1967886b79"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


class IntegrityError(Exception):
    pass


def load_index(root: Path) -> list[dict]:
    index_path = root / INDEX_REL
    raw = index_path.read_bytes()
    if sha256_bytes(raw) != INDEX_SHA256:
        raise IntegrityError(f"fixture index SHA-256 mismatch: {sha256_bytes(raw)}")
    fixtures = json.loads(raw)["fixtures"]
    ids = [f["fixture_id"] for f in fixtures]
    if len(fixtures) != EXPECTED_COUNT:
        raise IntegrityError(f"fixture count {len(fixtures)} != {EXPECTED_COUNT}")
    if len(set(ids)) != len(ids):
        raise IntegrityError("duplicate fixture IDs in index")
    on_disk = {p.name for p in (root / "41_F18_Fixture_Inputs").glob("*.json")} - {"fixture-index.json"}
    listed = {Path(f["path"]).name for f in fixtures}
    if on_disk != listed:
        raise IntegrityError(f"unlisted or missing descriptors: {sorted(on_disk ^ listed)}")
    return fixtures


def load_descriptor(root: Path, entry: dict) -> dict:
    raw = (root / entry["path"]).read_bytes()
    if len(raw) != entry["bytes"] or sha256_bytes(raw) != entry["sha256"]:
        raise IntegrityError(f"{entry['fixture_id']}: descriptor hash/length mismatch")
    desc = json.loads(raw)
    if desc["fixture_id"] != entry["fixture_id"]:
        raise IntegrityError(f"{entry['fixture_id']}: descriptor ID mismatch")
    if desc["expected"] != entry["expected"]:
        raise IntegrityError(f"{entry['fixture_id']}: index/descriptor expected mismatch")
    return desc


def load_schema_validator(root: Path):
    path = root / SCHEMA_REL
    if sha256_file(path) != SCHEMA_SHA256:
        raise IntegrityError(f"response schema SHA-256 mismatch: {sha256_file(path)}")
    return load_validator(path)


def failure_record(result: Failure) -> dict:
    return {
        "disposition": result.disposition,
        "stage_id": result.stage_id,
        "error_class": result.error_class,
        "diagnostic": result.diagnostic,
    }


class Blocked(Exception):
    """The fixture reaches a stage or rule that is not implemented (NOT_IMPLEMENTED)."""


ACCEPT = {"disposition": "ACCEPT", "stage_id": None, "error_class": None, "diagnostic": None}


SANDBOX: dict | None = None  # set by main() once the pinned image is verified
# D-005 DRAFT design materials for L166 (7)-(11); set by main(). Every result that uses
# them says what is still provisional or was cleared under a deviation (simulator_stages.prepare).
DESIGN_MATERIALS_FILE = "design/fifo/design-materials-DRAFT.json"
SIM: dict | None = None
SIM_UNAVAILABLE = "not prepared"
PROVISIONAL: dict = {}  # fixture descriptor id -> simulator details, filled by sim_stages


def source_stages(driver_source: str, checker_source: str) -> Failure | None:
    """SOURCE_AST, IMPORT_POLICY, static AST_SIGNATURE, COMPILE_DRIVER, COMPILE_CHECKER
    (Protocol §3.4 evaluation order (2)-(6)), then the sandboxed runtime import, factory
    return-type and signature checks (File 30 §3 L27, L39; L166 (7)). None means every
    implemented stage passed."""
    sources = {"driver.py": driver_source, "checker.py": checker_source}
    try:
        trees = check_sources(list(sources.items()))
        if isinstance(trees, Failure):
            return trees
        static = check_import_policy(sources, trees) or check_ast_signature(trees) or check_compile(sources)
    except UnsettledSpec as exc:
        raise Blocked(f"blocked on docs/ambiguities.md {exc}") from exc
    if static is not None:
        return static
    if SANDBOX is None:
        raise Blocked("static stages and compilation passed; sandbox unavailable, runtime stage not run")
    return factory_checks(driver_source)


def response_object(inp: dict) -> dict:
    """The response object a response input carries (envelope already accepted)."""
    if "response_object" in inp:
        return inp["response_object"]
    raw = (inp["raw_response_utf8"].encode("utf-8") if "raw_response_utf8" in inp
           else base64.b64decode(inp["raw_response_base64"], validate=True))
    return parse_envelope(raw, inp.get("provider_finish_reason")).obj


def sim_stages(desc: dict, obj: dict) -> Failure | None:
    """L166 (7)-(11) on the design materials (D-005); see SIM provisional/cleared."""
    if SIM is None:
        raise Blocked(RUNTIME_NEXT + f" [D-005 materials: {SIM_UNAVAILABLE}]")
    failure, details = simulator_stages.run_response(SIM, obj["driver"]["source"], obj["checker"]["source"])
    PROVISIONAL[id(desc)] = details
    return failure


def response_stages(desc: dict, inp: dict, validator) -> Failure | None:
    """Evaluation order (1)-(6) for a response input; None if all of them pass."""
    raw: bytes | None = None
    if "raw_response_utf8" in inp:
        raw = inp["raw_response_utf8"].encode("utf-8")
    elif "raw_response_base64" in inp:
        raw = base64.b64decode(inp["raw_response_base64"], validate=True)
    if raw is not None:
        envelope = parse_envelope(raw, inp.get("provider_finish_reason"))
        if isinstance(envelope, Failure):
            return envelope
        obj = envelope.obj
    else:
        # A-002 (owner decision): skip envelope decoding only.
        obj = inp["response_object"]
    # PARSE_SCHEMA part 1b; manifest clause_ids from the descriptor (A-005).
    checked = validate_schema(validator, obj)
    if isinstance(checked, ValidatedResponse):
        checked = validate_clause_ids(checked, desc["manifest_clause_ids"])
    if isinstance(checked, Failure):
        return checked
    return source_stages(obj["driver"]["source"], obj["checker"]["source"])


# L166 (7)-(11) are implemented (src/openvef/simulation.py, sandbox/sim.py; D-003 toolchain)
# but need inputs that are owner-written or TO FREEZE and absent from the pack.
MISSING_DESIGN_MATERIALS = ("FIFO RTL and null netlist; port manifest with widths; reset sequence; legal-input "
                            "predicate (owner-written FIFO specification, Scope); cycle cap, safe-idle vector and "
                            "watchdog formula (TO FREEZE, Protocol L229); observation mask (owner-written); "
                            "checker trace schema and metadata (TO FREEZE, L543)")
RUNTIME_NEXT = ("runtime import, factory and signature checks passed in the sandbox; L166 (7)-(11) simulator "
                "stages are built but blocked on design materials absent from the pack: " + MISSING_DESIGN_MATERIALS)


def two_runs(runs) -> tuple:
    if not isinstance(runs, list) or len(runs) != 2:
        raise Blocked("checker adjudication needs exactly two run records (L166 steps (9)-(10))")
    return outcome_from_record(runs[0]), outcome_from_record(runs[1])


def adapt_response(desc: dict, validator) -> Failure | dict | None:
    result = response_stages(desc, desc["input"], validator)
    return sim_stages(desc, response_object(desc["input"])) if result is None else result


def adapt_source_pair(desc: dict, validator) -> Failure | dict | None:
    """A-012 source pair."""
    result = source_stages(desc["input"]["driver_source"], desc["input"]["checker_source"])
    if result is None:
        raise Blocked(RUNTIME_NEXT)
    return result


def adapt_null_runs(desc: dict, validator) -> Failure | dict | None:
    """A-028: run every implemented response stage first; the supplied outcomes stand in."""
    inp = desc["input"]
    result = response_stages(desc, {"response_object": inp["response_object"]}, validator)
    return adjudicate_checker(*two_runs(inp["null_runs"])) if result is None else result


def adapt_events(desc: dict, validator) -> Failure | dict | None:
    return first_event(desc["input"]["events"])  # A-025


def adapt_checker_runs(desc: dict, validator) -> Failure | dict | None:
    return adjudicate_checker(*two_runs(desc["input"]["checker_runs"]))  # A-026


def adapt_halt_recurrence(desc: dict, validator) -> Failure | dict | None:
    """Ledger, Protocol L185. An out-of-domain supplied signature is a fixture defect (D-012)."""
    inp = desc["input"]
    try:
        first, second = (HaltSignature.given(inp[k]) for k in ("first_halt_signature", "second_halt_signature"))
    except SignatureDomainError as exc:
        raise Blocked(f"PD-01 fixture defect: supplied halt signature outside the Protocol L185 domains: {exc}") from exc
    return halt_after_recovery(first, second, inp["recovery_cycles_used"])


def adapt_change_class(desc: dict, validator) -> Failure | dict | None:
    """Ledger, Protocol L175-L176, L181-L185 (A-033 revised)."""
    try:
        record, missing = lifecycle_expectation(desc["input"]["change_class"])
    except ValueError as exc:
        raise Blocked(str(exc)) from exc
    if missing:
        raise Blocked("A-033: no supporting Protocol sentence for " +
                      "; ".join(f"{name}: {reason}" for name, reason in missing.items()))
    return record


def adapt_clause_ids(desc: dict, validator) -> Failure | dict | None:
    inp = desc["input"]
    result = check_visible_clause_ids(
        inp["visible_payload"], inp["manifest_clause_ids"], inp["clause_id_regex"],
        inp.get("clause_id_search_regex", SEARCH_REGEX_DEFAULT),
        inp.get("clause_id_near_match_regex", NEAR_MATCH_REGEX_DEFAULT))
    if result is None:
        raise Blocked("packet check passed; nothing further to compare")
    return result


# (required keys, optional keys, adapter). This table is the ONLY place an input shape
# selects code. D-012 (A1-1): an adapter that only one mandatory fixture can reach is not
# allowed; tests/test_dispatch_shapes.py enforces it.
ADAPTERS = (
    ({"raw_response_utf8"}, {"provider_finish_reason"}, adapt_response),
    ({"raw_response_base64"}, set(), adapt_response),
    ({"response_object"}, set(), adapt_response),
    ({"driver_source", "checker_source"}, set(), adapt_source_pair),
    ({"null_runs", "response_object"}, set(), adapt_null_runs),
    ({"events"}, set(), adapt_events),
    ({"checker_runs"}, set(), adapt_checker_runs),
    ({"design_id", "recovery_cycles_used", "first_halt_signature", "second_halt_signature", "scheduled_slots"}, set(),
     adapt_halt_recurrence),
    ({"change_class"}, set(), adapt_change_class),
    ({"visible_payload", "manifest_clause_ids", "clause_id_regex"},
     {"clause_id_search_regex", "clause_id_near_match_regex"}, adapt_clause_ids),
)


def find_adapters(inp: dict) -> list:
    """Every ADAPTERS row whose key sets fit the input (at most one)."""
    keys = set(inp)
    return [row for row in ADAPTERS if row[0] <= keys <= row[0] | row[1]]


def dispatch(desc: dict, validator) -> Failure | dict | None:
    """The outcome for one descriptor: a Failure, a full record, or None (ACCEPT).

    The code path is chosen from the input's key set only (CLAUDE.md rule 4).
    """
    rows = find_adapters(desc["input"])
    if not rows:
        raise Blocked(f"no adapter for this input shape: {sorted(desc['input'])}")
    return rows[0][2](desc, validator)


def execute(desc: dict, validator) -> tuple[str, dict | None, str]:
    """Return (status, actual, note)."""
    try:
        outcome = dispatch(desc, validator)
    except (Blocked, NotDetermined) as exc:
        return "NOT_IMPLEMENTED", None, str(exc)
    except EventError as exc:
        return "NOT_IMPLEMENTED", None, f"input outside the adapter vocabulary: {exc}"
    if outcome is None:
        return "EXECUTED", dict(ACCEPT), ""
    if isinstance(outcome, Failure):
        return "EXECUTED", failure_record(outcome), ""
    return "EXECUTED", outcome, ""


def installed_version(name: str) -> str | None:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return None


def git_commit() -> str:
    if broker_mode():  # D-002a: the host broker reads git; the runner container has no git
        return os.environ["OPENVEF_GIT_COMMIT"]
    try:
        out = subprocess.run(["git", "-C", str(REPO), "rev-parse", "HEAD"], capture_output=True, text=True, check=True)
        dirty = subprocess.run(["git", "-C", str(REPO), "status", "--porcelain", "--", "src", "runner", "sandbox",
                                "design", "docs/fifo-spec-v0.2.md"],
                               capture_output=True, text=True, check=True).stdout.strip()
        return out.stdout.strip() + ("+UNCOMMITTED_CHANGES" if dirty else "")
    except (subprocess.CalledProcessError, FileNotFoundError):
        return "NO_GIT_COMMIT"


def utc_stamp() -> str:
    """ISO 8601 UTC time with milliseconds, for each run.log fixture line (§3 item 6)."""
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def main() -> int:
    root, evidence_root, run_class = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
    if broker_mode():  # D-002a: the broker created and mounted the (empty) run directory
        started = os.environ["OPENVEF_RUN_STARTED"]
        out_dir = evidence_root
        if any(out_dir.iterdir()):
            raise IntegrityError("evidence directory is not empty")
    else:
        started = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        out_dir = evidence_root / f"run-{started}"
        out_dir.mkdir(parents=True, exist_ok=False)

    source_files = sorted([*(REPO / "src").rglob("*.py"), *(REPO / "runner").rglob("*.py"),
                           *(REPO / "sandbox").glob("*"), *(p for p in (REPO / "design").rglob("*") if p.is_file())])
    global SANDBOX
    try:
        SANDBOX = ensure_image()
    except (SandboxUnavailable, FileNotFoundError) as exc:
        SANDBOX = None
        print(f"sandbox unavailable: {exc}", file=sys.stderr)
    if broker_mode() and SANDBOX is None:
        raise SystemExit("D-002a: the runner container must have the sandbox identity")
    py_sha = sha256_file(Path(os.path.realpath(sys.executable)))
    pinned = broker_mode() and sys.version == PINNED_PYTHON_VERSION and py_sha == PINNED_PYTHON_SHA256
    meta = {
        "run_started_utc": started,
        "run_class": run_class,
        "interpreter_status": ("PINNED (D-002a: runner and artifacts in the pinned image)" if pinned else
                               "NOT_PINNED: development run, not F18 evidence (D-002a)"),
        "python_version": sys.version,
        "python_executable": sys.executable,
        "python_executable_sha256": py_sha,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "fixture_index_sha256": INDEX_SHA256,
        "response_schema_sha256": SCHEMA_SHA256,
        "distributions": {name: installed_version(name) for name in PINNED_DISTRIBUTIONS},
        "git_commit": git_commit(),
        "source_sha256": {str(p.relative_to(REPO)): sha256_file(p) for p in source_files},
        "command": [sys.executable, *sys.argv],
        "sandbox": SANDBOX,
    }

    global SIM, SIM_UNAVAILABLE
    if SANDBOX is not None:
        try:
            SIM = simulator_stages.prepare(REPO, DESIGN_MATERIALS_FILE)
            meta["design_materials"] = SIM["record"]
        except (OSError, KeyError, ValueError, SimulationError) as exc:
            SIM, SIM_UNAVAILABLE = None, f"{type(exc).__name__}: {exc}"
            meta["design_materials"] = {"unavailable": SIM_UNAVAILABLE}
    provisional_ids: list = []
    deviation_ids: list = []
    counts = {"PASS": 0, "FAIL": 0, "NOT_IMPLEMENTED": 0, "ERROR": 0}
    with open(out_dir / "results.jsonl", "w", encoding="utf-8") as res, open(out_dir / "run.log", "w", encoding="utf-8") as log:
        log.write(json.dumps(meta, indent=2) + "\n")
        fixtures = load_index(root)  # IntegrityError aborts the whole run
        validator = load_schema_validator(root)
        for entry in fixtures:
            desc = load_descriptor(root, entry)
            expected = desc["expected"]
            try:
                status, actual, note = execute(desc, validator)
            except Exception as exc:  # recorded, never hidden
                status, actual, note = "ERROR", None, f"{type(exc).__name__}: {exc}"
            if status == "EXECUTED":
                # Standard expectations compare the four fields; a control-vector
                # expectation compares the whole object exactly (A-032).
                status = "PASS" if actual == expected else "FAIL"
            counts[status] += 1
            rec = {"fixture_id": entry["fixture_id"], "descriptor_sha256": entry["sha256"], "status": status,
                   "expected": expected, "actual": actual, "note": note}
            sim_details = PROVISIONAL.pop(id(desc), None)
            if sim_details is not None and SIM["provisional"]:  # reached L166 (7)-(11); items still open
                rec["provisional"] = {"reason": "depends on design items not yet frozen or signed: "
                                                + "; ".join(SIM["provisional"]),
                                      "simulator": sim_details}
                provisional_ids.append(entry["fixture_id"])
            if sim_details is not None and SIM["cleared"]:
                rec["cleared_under_deviation"] = SIM["cleared"]
                rec["label"] = "; ".join(c["label"] for c in SIM["cleared"])
                rec.setdefault("simulator", sim_details)
                note = f"{note} [{rec['label']}]".strip()
                deviation_ids.append(entry["fixture_id"])
            res.write(json.dumps(rec, ensure_ascii=False, sort_keys=True) + "\n")
            log.write(f"{utc_stamp()} {entry['fixture_id']}: {status} {note}\n")
            log.flush()

    meta["run_finished_utc"] = utc_stamp()
    summary = {**meta, "counts": counts, "total": sum(counts.values()),
               "provisional_fixtures": provisional_ids,
               "deviation_cleared_fixtures": deviation_ids,
               "deviation_labels": sorted({c["label"] for c in SIM["cleared"]}) if SIM else [],
               "results_sha256": sha256_file(out_dir / "results.jsonl")}
    (out_dir / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"out_dir": str(out_dir), "run": f"run-{started}", "counts": counts}), file=sys.stderr)
    return 0 if counts["FAIL"] == 0 and counts["ERROR"] == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
